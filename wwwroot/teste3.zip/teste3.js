﻿//--- TODO
function recalculate() {
    //--- TODO: escrever o código em falta aqui...

}

function send() {
    //--- TODO: escrever o código em falta aqui...
    //--- Se a função retornar true o formulário será enviado; 
    //--- Se a função retornar false, o formulário não será enviaddo.

}